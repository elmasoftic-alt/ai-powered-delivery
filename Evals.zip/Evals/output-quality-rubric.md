# Output Quality Rubric

**Purpose:** Simple scoring system to evaluate quality of AI-generated analyses  
**Created:** 2026-06-17  
**Applies to:** PM Analysis, EM Analysis, C-Level Analysis, Meeting Summaries

---

## Quick Score (1-5 scale per category)

### 1. Completeness (5 points)
**Does the analysis include all expected sections?**

- [ ] Strategic context / Executive summary present
- [ ] Decisions table present (if applicable)
- [ ] Risks table with severity flags present (if applicable)
- [ ] Action items / Next steps present
- [ ] Jira ticket references present (if applicable)

**Score:**
- 5 = All sections present
- 4 = Missing 1 section
- 3 = Missing 2 sections
- 2 = Missing 3 sections
- 1 = Missing 4+ sections

---

### 2. Accuracy (5 points)
**Are the facts correct vs. source material?**

- [ ] Names/roles are correct
- [ ] Dates/timelines are correct
- [ ] Initiative names match source
- [ ] No hallucinated Jira ticket IDs
- [ ] No contradictions within the analysis

**Score:**
- 5 = All facts accurate
- 4 = 1 minor inaccuracy
- 3 = 2-3 minor inaccuracies
- 2 = Major inaccuracy or contradiction
- 1 = Multiple major inaccuracies

---

### 3. Actionability (5 points)
**Are next steps clear and useful?**

- [ ] Next steps are specific (not vague)
- [ ] Risks have owners/teams identified
- [ ] Decisions have clear impact statements
- [ ] Dependencies are identified
- [ ] Timelines/deadlines are mentioned

**Score:**
- 5 = All action items clear and assignable
- 4 = 1 vague action item
- 3 = 2-3 vague action items
- 2 = Most action items vague
- 1 = No actionable next steps

---

## Total Score Interpretation

| Total Score | Rating | Action |
|-------------|--------|--------|
| 13-15 | ✅ Excellent | Ship as-is |
| 10-12 | 🟡 Good | Minor edits before shipping |
| 7-9 | 🟠 Needs Work | Major revision required |
| 1-6 | 🔴 Poor | Re-generate with different prompt |

---

## Common Patterns to Watch For

### Red Flags 🚨
- Hallucinated Jira ticket IDs (e.g., DCFF-9999 that doesn't exist)
- Generic action items ("Follow up with team")
- Missing risk severity indicators (🔴/🟠/🟡)
- No cross-references to previous wiki pages or decisions-log.md
- Copy-paste errors (wrong meeting title, wrong date)

### Quality Indicators ✅
- Specific Jira ticket links with real IDs
- Named owners for action items
- Risk severity with justification
- Cross-references to dependency-map.md or domain-glossary.md
- Consistent formatting per page type (PM/EM/C-Level)

---

## Evaluation Process

1. **Select sample:** 10% of analyses OR minimum 10 files per month
2. **Score using rubric:** Fill out checklist for each category
3. **Calculate total:** Sum of 3 categories (max 15)
4. **Log in eval-log.md:** Record score + notes
5. **Identify patterns:** Monthly review for common gaps
6. **Update skills:** If pattern found, update PM/EM/C-Level skill prompts

---

## Example Evaluation

**File:** `OnRep-Favorites-PM-Analysis-2026-04-27.md`  
**Type:** PM Analysis  
**Evaluator:** Elma  
**Date:** 2026-06-17

**Completeness:** 5/5 (all sections present)  
**Accuracy:** 4/5 (1 minor date formatting inconsistency)  
**Actionability:** 5/5 (clear owners, specific next steps)  

**Total:** 14/15 → ✅ Excellent

**Notes:** Excellent quality. Only minor issue was date format (used US format instead of ISO). No changes needed before Confluence post.
