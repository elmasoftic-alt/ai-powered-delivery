# Eval System — Next Actions

**Created:** 2026-06-17  
**Based on:** Baseline evaluation results (avg score 8.8/15)  
**Goal:** Increase average score from 8.8 → 12+ within 2 weeks

---

## Immediate Actions (This Week)

### 1. Update PM Analysis Skill — Add Jira Section Requirement ⏰ 30 min
**Issue:** 80% of analyses missing Jira ticket section  
**Impact:** Low traceability to delivery work

**Action:**
- [ ] Open `.github/skills/PM Analysis/SKILL.md`
- [ ] Add explicit "## Jira Tickets" section to output template
- [ ] Add prompt: "Which Jira tickets (DCFF-XXX) are mentioned or directly related to this discussion?"
- [ ] Add validation: "If no tickets mentioned, state 'No Jira tickets discussed'"

**Expected improvement:** Missing Jira sections 80% → 0%

---

### 2. Add Cross-Reference Prompt to Workflow ⏰ 20 min
**Issue:** 100% of analyses lack cross-references to workspace files  
**Impact:** Analyses exist in isolation, knowledge not connected

**Action:**
- [ ] Open `.github/skills/PM Analysis/SKILL.md`
- [ ] Before generating output, add step:
  ```
  "Does this topic relate to any initiative in:
  - dependency-map.md (blocked dependencies, escalations)
  - annual-goals.md (strategic priorities)
  - domain-glossary.md (domain terms needing definition)
  If yes, add inline cross-reference link."
  ```
- [ ] Add example: `This aligns with [OnRep Q3 goals](../AI/Memory/annual-goals.md#onrep).`

**Expected improvement:** Cross-references 0% → 60%+

---

### 3. Strengthen Action Item Formatting ⏰ 15 min
**Issue:** 100% of analyses lack named owners in action items  
**Impact:** Reduced actionability

**Action:**
- [ ] Open `.github/skills/PM Analysis/SKILL.md`
- [ ] Update action items section format requirement:
  ```markdown
  ## Action Items
  
  | Priority | Action | Owner | Due Date |
  |----------|--------|-------|----------|
  | 🔴 P0 | [Specific action] | **[Name]** | YYYY-MM-DD |
  ```
- [ ] Add validation: "Every action item MUST have a named owner. If unclear from transcript, state 'Owner: TBD — [Elma to assign]'"

**Expected improvement:** Named owners 0% → 80%+

---

### 4. Add "TBD" as Red Flag in Eval Runner ⏰ 5 min
**Issue:** 40% of analyses contain "TBD" placeholders  
**Impact:** Low actionability signal

**Action:**
- [ ] Open `Web Foundation/AI/Evals/eval-runner.py`
- [ ] Confirm "TBD" is in `RED_FLAGS['generic_actions']` list (already present)
- [ ] Test: Run eval again and verify TBD is flagged

**Expected improvement:** Generic actions 40% → 10%

---

## Short-Term Actions (Next 2 Weeks)

### 5. Re-Evaluate After Skill Updates (A/B Test) ⏰ 30 min
**Action:**
- [ ] Select 3 recent transcripts
- [ ] Generate analyses using UPDATED PM Analysis skill
- [ ] Run `eval-runner.py` on new analyses
- [ ] Compare scores: Old avg 8.8 vs New avg (target: 12+)
- [ ] Document results in `eval-log.md`

**Success criteria:** Average score increases to 12+ (Good tier)

---

### 6. Expand Baseline Sample ⏰ 15 min
**Action:**
- [ ] Run `python3 eval-runner.py --batch 15` (10 more analyses)
- [ ] Check if patterns hold across broader sample
- [ ] Update baseline report if needed

**Success criteria:** Statistical validity with 15+ samples

---

### 7. Manual Validation of Automated Scores ⏰ 45 min
**Action:**
- [ ] Select 3 analyses (1 Good, 1 Needs Work, 1 Poor)
- [ ] Manually score using `output-quality-rubric.md`
- [ ] Compare manual vs automated scores
- [ ] Identify calibration gaps
- [ ] Update `eval-runner.py` if patterns missed

**Success criteria:** Manual scores within ±2 points of automated scores

---

## Monthly Actions

### 8. Weekly Eval Cadence ⏰ 15 min/week
**Action:**
- [ ] Every Friday 4pm: Run `eval-runner.py --batch 10`
- [ ] Spot-check 2-3 files manually
- [ ] Log results in `eval-log.md`
- [ ] Flag new patterns

**Success criteria:** Consistent tracking, trend data builds

---

### 9. Monthly Summary Report ⏰ 30 min/month
**Action:**
- [ ] First Friday of each month: Calculate monthly stats
- [ ] Update `eval-log.md` Monthly Summary section
- [ ] Identify top 3 issues
- [ ] Create action plan for next month

**Success criteria:** Month-over-month improvement visible

---

## Progress Tracking

| Action | Status | Completed Date | Impact on Score |
|--------|--------|----------------|-----------------|
| 1. Update PM Analysis skill (Jira) | ⬜ Not started | - | Est. +2 points |
| 2. Add cross-reference prompt | ⬜ Not started | - | Est. +1 point |
| 3. Strengthen action item format | ⬜ Not started | - | Est. +1 point |
| 4. Add TBD red flag | ⬜ Not started | - | Quality signal |
| 5. Re-evaluate (A/B test) | ⬜ Not started | - | Validation |
| 6. Expand baseline sample | ⬜ Not started | - | Statistical validity |
| 7. Manual validation | ⬜ Not started | - | Calibration |

**Target:** Complete actions 1-4 by 2026-06-24 (1 week)

---

## Expected Outcomes (1 Month)

| Metric | Baseline (2026-06-17) | Target (2026-07-17) | Status |
|--------|----------------------|---------------------|--------|
| Average Score | 8.8/15 | 12+/15 | ⬜ |
| % Excellent | 0% | 40% | ⬜ |
| % with Jira Section | 20% | 100% | ⬜ |
| % with Cross-Refs | 0% | 60% | ⬜ |
| % with Named Owners | 0% | 80% | ⬜ |
| % with Generic Actions | 40% | 10% | ⬜ |

---

**Owner:** Elma Softic  
**Review Cadence:** Weekly (Fridays)  
**Next Review:** 2026-06-24
