#!/usr/bin/env python3
"""
Simple Evaluation Runner for AI-Generated Analyses

Usage:
    python3 eval-runner.py --file "path/to/analysis.md"
    python3 eval-runner.py --batch 10  # Evaluate 10 most recent
    python3 eval-runner.py --all       # Evaluate all analyses

Output: Completeness score + quality report
"""

import os
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple

# Expected sections for each analysis type
SECTION_PATTERNS = {
    'PM-Analysis': [
        r'##\s+(Strategic Context|Executive Summary|Context)',
        r'##\s+(Key Decisions|Decisions)',
        r'##\s+(Risks?|Risk Assessment)',
        r'##\s+(Action Items?|Next Steps)',
        r'##\s+(Jira|Tickets?|DCFF)'
    ],
    'EM-Analysis': [
        r'##\s+(Technical Context|Engineering Context)',
        r'##\s+(Architecture|Technical Decisions)',
        r'##\s+(Risks?|Technical Risks)',
        r'##\s+(Action Items?|Engineering Actions)',
    ],
    'Meeting-Summary': [
        r'##\s+(Attendees|Participants)',
        r'##\s+(Key Discussion|Discussion|Topics)',
        r'##\s+(Decisions|Key Decisions)',
        r'##\s+(Action Items?|Next Steps)',
    ]
}

# Red flags to detect
RED_FLAGS = {
    'hallucinated_jira': r'DCFF-\d{4,}',  # Suspiciously high ticket numbers
    'generic_actions': [
        'follow up with team',
        'discuss further',
        'to be determined',
        'TBD',
        'review and update'
    ],
    'missing_severity': r'Risk(?!.*(?:🔴|🟠|🟡|\*\*High\*\*|\*\*Medium\*\*|\*\*Low\*\*))',
}

# Quality indicators
QUALITY_INDICATORS = {
    'jira_links': r'\[DCFF-\d+\]\(https://hmgroup\.atlassian\.net',
    'severity_flags': r'🔴|🟠|🟡',
    'cross_references': r'\[.*?\]\(.*?(?:dependency-map|domain-glossary|decisions-log|annual-goals).*?\)',
    'named_owners': r'(?:Owner|Assignee|DRI):\s*\*\*[A-Z][a-z]+',
}


def detect_analysis_type(content: str, filename: str) -> str:
    """Detect analysis type from filename or content."""
    if 'PM-Analysis' in filename:
        return 'PM-Analysis'
    elif 'EM-Analysis' in filename:
        return 'EM-Analysis'
    elif 'Meeting-Summary' in filename or 'transcript' in filename.lower():
        return 'Meeting-Summary'
    else:
        return 'PM-Analysis'  # Default


def check_completeness(content: str, analysis_type: str) -> Tuple[int, List[str]]:
    """
    Check for expected sections.
    Returns: (score out of 5, list of missing sections)
    """
    expected = SECTION_PATTERNS.get(analysis_type, SECTION_PATTERNS['PM-Analysis'])
    found = []
    missing = []
    
    for pattern in expected:
        if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
            found.append(pattern)
        else:
            missing.append(pattern)
    
    # Score: 5 if all present, scale down linearly
    total = len(expected)
    found_count = len(found)
    score = round((found_count / total) * 5) if total > 0 else 0
    
    return score, [p.replace(r'##\s+', '').replace(r'\s+', ' ') for p in missing]


def check_red_flags(content: str) -> List[str]:
    """Detect quality red flags."""
    flags = []
    
    # Check for generic action items
    for generic in RED_FLAGS['generic_actions']:
        if generic.lower() in content.lower():
            flags.append(f"Generic action item: '{generic}'")
    
    # Check for missing risk severity (if risks section exists)
    if re.search(r'##\s+Risk', content, re.IGNORECASE):
        # Extract risk section
        risk_match = re.search(r'##\s+Risk.*?\n(.*?)(?=\n##|\Z)', content, re.IGNORECASE | re.DOTALL)
        if risk_match:
            risk_section = risk_match.group(1)
            if not re.search(r'🔴|🟠|🟡|\*\*High\*\*|\*\*Medium\*\*|\*\*Low\*\*', risk_section):
                flags.append("Risks missing severity flags (🔴/🟠/🟡)")
    
    return flags


def check_quality_indicators(content: str) -> Dict[str, int]:
    """Count quality indicators."""
    indicators = {}
    
    for name, pattern in QUALITY_INDICATORS.items():
        matches = re.findall(pattern, content, re.IGNORECASE)
        indicators[name] = len(matches)
    
    return indicators


def evaluate_file(filepath: Path) -> Dict:
    """Evaluate a single analysis file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    analysis_type = detect_analysis_type(content, filepath.name)
    completeness_score, missing = check_completeness(content, analysis_type)
    red_flags = check_red_flags(content)
    indicators = check_quality_indicators(content)
    
    # Simple auto-score (completeness only - accuracy/actionability require human review)
    # Max 5 for completeness, estimate accuracy/actionability at 4 if no red flags
    estimated_accuracy = 4 if len(red_flags) == 0 else 3
    estimated_actionability = 4 if indicators['named_owners'] > 0 else 3
    
    total_score = completeness_score + estimated_accuracy + estimated_actionability
    
    if total_score >= 13:
        rating = "✅ Excellent"
    elif total_score >= 10:
        rating = "🟡 Good"
    elif total_score >= 7:
        rating = "🟠 Needs Work"
    else:
        rating = "🔴 Poor"
    
    return {
        'file': filepath.name,
        'type': analysis_type,
        'completeness': completeness_score,
        'estimated_accuracy': estimated_accuracy,
        'estimated_actionability': estimated_actionability,
        'total': total_score,
        'rating': rating,
        'missing_sections': missing,
        'red_flags': red_flags,
        'indicators': indicators,
    }


def print_report(result: Dict):
    """Print evaluation report for a file."""
    print(f"\n{'='*70}")
    print(f"File: {result['file']}")
    print(f"Type: {result['type']}")
    print(f"{'='*70}")
    print(f"\nSCORES:")
    print(f"  Completeness:        {result['completeness']}/5")
    print(f"  Accuracy (est):      {result['estimated_accuracy']}/5 ⚠️  Manual review needed")
    print(f"  Actionability (est): {result['estimated_actionability']}/5 ⚠️  Manual review needed")
    print(f"  ───────────────────────")
    print(f"  TOTAL:               {result['total']}/15")
    print(f"  RATING:              {result['rating']}")
    
    if result['missing_sections']:
        print(f"\n❌ MISSING SECTIONS:")
        for section in result['missing_sections']:
            print(f"   - {section}")
    
    if result['red_flags']:
        print(f"\n🚨 RED FLAGS:")
        for flag in result['red_flags']:
            print(f"   - {flag}")
    
    print(f"\n✅ QUALITY INDICATORS:")
    print(f"   - Jira links: {result['indicators']['jira_links']}")
    print(f"   - Severity flags: {result['indicators']['severity_flags']}")
    print(f"   - Cross-references: {result['indicators']['cross_references']}")
    print(f"   - Named owners: {result['indicators']['named_owners']}")
    
    print(f"\n{'='*70}\n")


def get_recent_analyses(outputs_dir: Path, count: int = 10) -> List[Path]:
    """Get N most recent analysis files."""
    files = []
    for f in outputs_dir.glob('*-Analysis-*.md'):
        files.append(f)
    
    # Sort by modification time, most recent first
    files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return files[:count]


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Evaluate AI-generated analysis quality')
    parser.add_argument('--file', type=str, help='Evaluate single file')
    parser.add_argument('--batch', type=int, help='Evaluate N most recent analyses')
    parser.add_argument('--all', action='store_true', help='Evaluate all analyses')
    
    args = parser.parse_args()
    
    # Determine workspace root
    script_dir = Path(__file__).parent
    workspace_root = script_dir.parent.parent.parent
    outputs_dir = workspace_root / 'Web Foundation' / 'Outputs'
    
    if not outputs_dir.exists():
        print(f"❌ ERROR: Outputs directory not found: {outputs_dir}")
        return
    
    # Determine which files to evaluate
    files_to_eval = []
    
    if args.file:
        file_path = Path(args.file)
        if not file_path.exists():
            # Try relative to outputs dir
            file_path = outputs_dir / args.file
        if not file_path.exists():
            print(f"❌ ERROR: File not found: {args.file}")
            return
        files_to_eval = [file_path]
    
    elif args.batch:
        files_to_eval = get_recent_analyses(outputs_dir, args.batch)
        print(f"📊 Evaluating {len(files_to_eval)} most recent analyses...")
    
    elif args.all:
        files_to_eval = list(outputs_dir.glob('*-Analysis-*.md'))
        print(f"📊 Evaluating all {len(files_to_eval)} analyses...")
    
    else:
        # Default: evaluate 10 most recent
        files_to_eval = get_recent_analyses(outputs_dir, 10)
        print(f"📊 Evaluating {len(files_to_eval)} most recent analyses (default)...")
    
    # Run evaluations
    results = []
    for filepath in files_to_eval:
        result = evaluate_file(filepath)
        results.append(result)
        print_report(result)
    
    # Summary statistics
    if len(results) > 1:
        avg_score = sum(r['total'] for r in results) / len(results)
        excellent = sum(1 for r in results if r['total'] >= 13)
        good = sum(1 for r in results if 10 <= r['total'] < 13)
        needs_work = sum(1 for r in results if 7 <= r['total'] < 10)
        poor = sum(1 for r in results if r['total'] < 7)
        
        print(f"\n{'='*70}")
        print(f"SUMMARY STATISTICS ({len(results)} files)")
        print(f"{'='*70}")
        print(f"Average Score: {avg_score:.1f}/15")
        print(f"\nDistribution:")
        print(f"  ✅ Excellent (13-15): {excellent}")
        print(f"  🟡 Good (10-12):      {good}")
        print(f"  🟠 Needs Work (7-9):  {needs_work}")
        print(f"  🔴 Poor (1-6):        {poor}")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    main()
