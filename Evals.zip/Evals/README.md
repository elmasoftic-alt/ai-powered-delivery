# AI Workspace Evaluation System

**Created:** 2026-06-01  
**Purpose:** Simple quality evaluation system for AI-generated analyses  
**Status:** ✅ Active — Baseline established

---

## Quick Start

### ⚠️ Important: Human-in-the-Loop Required

**The automated eval is a SCREENING TOOL, not the final judge.**

- ✅ Automation checks: Section structure, formatting, patterns
- ❌ Automation CANNOT verify: Facts, accuracy, hallucinations, quality judgment
- 🧠 **YOU are the judge** — Review automated results and apply your judgment

### Run an Evaluation

```bash
cd "Web Foundation/AI/Evals"

# Evaluate 10 most recent analyses (default)
python3 eval-runner.py

# Evaluate specific file
python3 eval-runner.py --file "../Outputs/OnRep-PM-Analysis-2026-06-10.md"

# Evaluate 20 most recent
python3 eval-runner.py --batch 20

# Evaluate all analyses
python3 eval-runner.py --all
```

### Interpret Results

| Score | Rating | Meaning |
|-------|--------|---------|
| 13-15 | ✅ Excellent | Ship as-is |
| 10-12 | 🟡 Good | Minor edits before sharing |
| 7-9 | 🟠 Needs Work | Major revision required |
| 1-6 | 🔴 Poor | Re-generate with different approach |

---

## What Gets Evaluated

### Automated Checks (eval-runner.py)

**✅ Completeness (5 points)**
- Strategic context section present?
- Decisions table present?
- Risks section present?
- Action items present?
- Jira tickets section present?

**⚠️ Accuracy (estimated 3-4 points) — HUMAN REVIEW REQUIRED**
- Automation detects: Red flags (generic actions, missing severity)
- Automation CANNOT verify: Facts vs transcript, hallucinated details, dates
- **YOU must validate:** Check facts against source material

**⚠️ Actionability (estimated 3-4 points) — HUMAN REVIEW REQUIRED**
- Automation detects: Named owners present, quality indicators
- Automation CANNOT verify: Whether actions are actually useful
- **YOU must validate:** Are next steps specific and assignable?

**Quality Indicators:**
- Jira links formatted correctly
- Severity flags (🔴/🟠/🟡) present on risks
- Cross-references to workspace files (dependency-map.md, etc.)
- Named owners in action items

**Red Flags:**
- Generic action items ("follow up with team", "TBD", etc.)
- Missing risk severity when risks section exists
- Hallucinated Jira ticket IDs

---

## Files in This System

| File | Purpose |
|------|---------|
| **output-quality-rubric.md** | Scoring criteria (1-5 scale per category) |
| **eval-log.md** | Historical record of all evaluations |
| **eval-runner.py** | Automated quality checker script |
| **baseline-eval-2026-06-17.md** | Initial quality baseline (avg 8.8/15) |
| **README.md** | This file |

---

## Workflow

### Weekly Evaluation (15 min) — Human-in-the-Loop

**Step 1: Automated Pre-Screen (5 min)**
```bash
cd "Web Foundation/AI/Evals"
python3 eval-runner.py --batch 10
```
This flags structural issues, missing sections, and patterns.

**Step 2: YOU Review Flagged Files (8 min)**
- Pick 2-3 files (prioritize: files rated "Needs Work" or "Poor", P0/P1 initiatives, Confluence posts)
- Open `output-quality-rubric.md`
- **Verify facts against source transcript:**
  - Are names/dates/initiatives correct?
  - Did AI hallucinate any Jira tickets?
  - Are risks real or overblown?
  - Are action items actually useful?
- **Score using YOUR judgment** — Trust yourself over automation

**Step 3: Log YOUR Scores in eval-log.md (2 min)**
- Add row with YOUR human-validated scores
- Mark "Evaluator: Elma" (not "Auto")
- Note what you corrected vs automated scores

**Step 4: Pattern Action**
- If same issue appears 3+ times → Flag for skill update
- If new hallucination pattern → Add to eval-runner.py red flags

### Monthly Review (30 min)

1. **Calculate summary stats:**
   - Average score across month
   - Distribution (Excellent/Good/Needs Work/Poor)
   - Trend vs previous month

2. **Update eval-log.md Monthly Summary section**

3. **Identify top 3 recurring issues**

4. **Create action plan:**
   - Update skills/prompts
   - Add examples to documentation
   - Refine automated checks

### Quarterly Review (PI Planning)

1. **Compare trends across 3 months**
2. **Measure improvement from skill updates (A/B tests)**
3. **Report in quarterly ROI dashboard**

---

## Current Status

### Baseline (2026-06-17)
- **Sample:** 5 most recent PM analyses
- **Average Score:** 8.8/15 (🟠 Needs Work)
- **Distribution:** 0% Excellent, 40% Good, 40% Needs Work, 20% Poor

### Top Issues Found
1. **Missing Jira sections (80%)** — Not linking to tickets
2. **No cross-references (100%)** — Analyses isolated from knowledge base
3. **No named owners (100%)** — Action items lack assignment
4. **Generic placeholders (40%)** — "TBD" instead of specific actions

### Immediate Actions (This Week)
- [ ] Update PM Analysis skill to require Jira section
- [ ] Add cross-reference prompt to workflow
- [ ] Strengthen action item formatting requirements
- [ ] Re-run eval after changes to measure improvement

---

## Extending the System

### Add New Analysis Type

Edit `eval-runner.py` → `SECTION_PATTERNS` dictionary:

```python
SECTION_PATTERNS = {
    'Your-New-Type': [
        r'##\s+(Expected Section 1)',
        r'##\s+(Expected Section 2)',
    ]
}
```

### Add New Red Flag

Edit `eval-runner.py` → `RED_FLAGS` dictionary:

```python
RED_FLAGS = {
    'your_flag_name': r'regex pattern to detect',
}
```

### Add New Quality Indicator

Edit `eval-runner.py` → `QUALITY_INDICATORS` dictionary:

```python
QUALITY_INDICATORS = {
    'your_indicator': r'regex pattern to count',
}
```

---

## Integration with Other Systems

### Link to Metrics Dashboard
- Eval results feed into `Web Foundation/AI/Metrics/adoption-dashboard-YYYY-WXX.md`
- Quality score becomes a tracked metric

### Link to Skills
- Patterns from eval-log.md inform skill updates
- A/B test before/after skill changes using eval-runner.py

### Link to ROI Reporting
- Quality improvement over time shows AI maturity
- Time saved estimate validated by consistent quality

---

## FAQs

**Q: Can I trust the automated scores?**  
A: **Only for completeness (section structure).** Accuracy and actionability are ESTIMATES. The AI can hallucinate — YOU must verify facts against source material.

**Q: Why are accuracy/actionability scores "estimated"?**  
A: The script can't verify facts against source transcripts automatically. It uses proxies (red flags, quality indicators) but **cannot detect hallucinations, factual errors, or quality judgment issues**.

**Q: What can the AI hallucinate?**  
A: Jira ticket IDs, people names/roles, dates, technical facts, risk severity. **Always check P0/P1 analyses and Confluence posts manually.**

**Q: What sample size is needed for valid statistics?**  
A: Minimum 10 evaluations per month. For skill A/B testing, 10 files per variant.

**Q: Should I evaluate every analysis?**  
A: No. Automated screen on 10 files, human review on 2-3 (prioritize P0/P1 initiatives and Confluence posts).

**Q: What if automated score disagrees with my manual review?**  
A: **Always trust YOUR review.** Use disagreements to improve eval-runner.py (add missing patterns). Log YOUR score in eval-log.md, not the automated one.

---

## Version History

| Date | Version | Changes |
|------|---------|---------|
| 2026-06-17 | 1.0 | Initial release with baseline eval |

---

## Critical Reminder

**🧠 YOU are the judge. The automation is a filter.**

- Automation saves time by flagging structural issues
- Automation CANNOT verify facts or prevent hallucinations  
- Always validate P0/P1 analyses and Confluence posts manually
- Trust your judgment over automated scores
- Log YOUR validated scores in eval-log.md

---

**Owner:** Elma Softic  
**Maintained by:** AI Workspace Evolution  
**Next Review:** 2026-06-24 (Post skill-update re-eval)
